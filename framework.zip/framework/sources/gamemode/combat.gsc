// 📌 187 — FRAMEWORK

////////////////////////////////////////////////////////////////////////

// File: combat.gsc

////////////////////////////////////////////////////////////////////////

// Framework-owned combat systems
//
// Current rebuilt feature:
// - fw_inf_ammo

////////////////////////////////////////////////////////////////////////

init()
{
    level endon("game_ended");

    if (getDvarInt("fw_inf_ammo") != 0 && getDvarInt("fw_inf_ammo") != 1)
        setDvar("fw_inf_ammo", "0");

    level.frameworkInfAmmoState = getDvarInt("fw_inf_ammo");
    level.frameworkLastInfAmmoState = -1;

    level thread watchInfiniteAmmoDvar();
}

////////////////////////////////////////////////////////////////////////

onPlayerConnected()
{
    self endon("disconnect");

    for (;;)
    {
        self waittill("spawned_player");

        self notify("stop_framework_combat_spawn");
        self thread frameworkCombatSpawn();
    }
}

////////////////////////////////////////////////////////////////////////

onPlayerSpawned()
{
    self endon("disconnect");

    self notify("stop_framework_combat_spawn");
    self thread frameworkCombatSpawn();
}

////////////////////////////////////////////////////////////////////////

frameworkCombatSpawn()
{
    self endon("disconnect");
    self endon("death");
    self endon("stop_framework_combat_spawn");
    level endon("game_ended");

    wait 0.15;

    if (level.frameworkInfAmmoState == 1)
        self thread runInfiniteAmmoLoop();
}

////////////////////////////////////////////////////////////////////////

watchInfiniteAmmoDvar()
{
    level endon("game_ended");

    for (;;)
    {
        wait 0.25;

        newState = getDvarInt("fw_inf_ammo");

        if (newState != 0 && newState != 1)
        {
            newState = 0;
            setDvar("fw_inf_ammo", "0");
        }

        if (newState == level.frameworkLastInfAmmoState)
            continue;

        level.frameworkLastInfAmmoState = newState;
        level.frameworkInfAmmoState = newState;

        if (newState == 1)
        {
            foreach (player in level.players)
            {
                if (!isDefined(player) || !isPlayer(player))
                    continue;

                player notify("stop_framework_inf_ammo");

                if (isAlive(player))
                    player thread runInfiniteAmmoLoop();

                player iprintln(level.prefix + "^5[COMBAT]^7 » ^2Infinite Ammo:^7 ^2Enabled");
            }
        }
        else
        {
            foreach (player in level.players)
            {
                if (!isDefined(player) || !isPlayer(player))
                    continue;

                player notify("stop_framework_inf_ammo");
                player iprintln(level.prefix + "^5[COMBAT]^7 » ^2Infinite Ammo:^7 ^1Disabled");
            }
        }
    }
}

////////////////////////////////////////////////////////////////////////

runInfiniteAmmoLoop()
{
    self endon("disconnect");
    self endon("death");
    self endon("stop_framework_combat_spawn");
    self endon("stop_framework_inf_ammo");
    level endon("game_ended");

    for (;;)
    {
        if (level.frameworkInfAmmoState != 1)
            return;

        if (!isAlive(self))
            return;

        self refillCurrentWeapons();
        wait 0.10;
    }
}

////////////////////////////////////////////////////////////////////////

refillCurrentWeapons()
{
    primary = self getCurrentWeapon();

    if (isDefined(primary) && primary != "")
        self refillWeaponAmmo(primary);

    offhandPrimary = self getCurrentOffhand();

    if (isDefined(offhandPrimary) && offhandPrimary != "")
        self giveMaxAmmo(offhandPrimary);
}

////////////////////////////////////////////////////////////////////////

refillWeaponAmmo(weapon)
{
    if (!isDefined(weapon) || weapon == "")
        return;

    self giveMaxAmmo(weapon);

    clipSize = weaponClipSize(weapon);

    if (isDefined(clipSize) && clipSize > 0)
        self setWeaponAmmoClip(weapon, clipSize);
}